//
//  Filter.swift
//  ProjectTeams
//
//  Created by Jacob Bee Ho Brown on 11/26/18.
//  Copyright © 2018 CS 1998. All rights reserved.
//

import Foundation

struct Filter {
    let name: String?
}

