//
//  TeamInfoTableViewCell.swift
//  ProjectTeams
//
//  Created by Jacob Bee Ho Brown on 11/29/18.
//  Copyright © 2018 CS 1998. All rights reserved.
//

import UIKit

class TeamInfoTableViewCell: UITableViewCell {

    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
