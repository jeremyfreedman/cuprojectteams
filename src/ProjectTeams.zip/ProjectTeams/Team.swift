//
//  Team.swift
//  
//
//  Created by Jacob Bee Ho Brown on 11/30/18.
//

import Foundation

struct Team {
    let image: String?
    let name: String?
    let type: String?
}
